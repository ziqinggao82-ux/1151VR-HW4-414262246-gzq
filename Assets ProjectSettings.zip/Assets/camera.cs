using UnityEngine;

public class camera : MonoBehaviour
{
    public Transform target;
    public float distance = 10f;
    public float height = 3f;

    void LateUpdate()
    {
        transform.position = target.position - target.forward * distance + Vector3.up * height;
        transform.LookAt(target.position + target.forward * 20f);
    }
}