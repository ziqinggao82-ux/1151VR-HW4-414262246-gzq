using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    public float forwardSpeed = 15f;
    public float moveSpeed = 8f;
    public float minX = -200f, maxX = 200f, minY = 0f, maxY = 60f;

    public float hitCooldown = 1.5f;
    public float stunTime = 0.5f;
    public float buttonDelay = 2f;

    public GameObject[] hearts;
    public GameObject gameOverPanel;
    public GameObject restartButton;
    public GameObject winPanel;        // 拖入 WinPanel

    public AudioSource flySound;
    public AudioSource hitSound;
    public AudioSource finalHitSound;
    public AudioSource passSound;
    public AudioSource winSound;       // 可不拖,沒有就用 passSound

    [Header("通過檢查點(Z 座標,依飛行順序填)")]
    public float[] passZ;
    public bool flyingTowardNegativeZ = true;

    [Header("通關位置")]
    public float winZ = 0f;            // 飛到這個 Z 就通關

    Rigidbody rb;
    int lives;
    int nextPass = 0;
    bool alive = true;
    bool canRestart = false;
    float lastHitTime = -999f;
    float stunUntil = 0f;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        lives = hearts.Length;
        Time.timeScale = 1f;

        if (gameOverPanel != null) gameOverPanel.SetActive(false);
        if (restartButton != null) restartButton.SetActive(false);
        if (winPanel != null) winPanel.SetActive(false);
        if (flySound != null) flySound.Play();
    }

    void Update()
    {
        // 結束後(失敗或通關),等待時間過了,點螢幕任何地方重新開始
        if (canRestart)
        {
            bool tapped = Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began;
            if (tapped || Input.GetMouseButtonDown(0))
                Restart();
        }
    }

    void FixedUpdate()
    {
        if (!alive || Time.time < stunUntil) return;

        float x = 0f, y = 0f;

        if (Input.GetKey(KeyCode.LeftArrow)  || Input.GetKey(KeyCode.A)) x -= 1f;
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)) x += 1f;
        if (Input.GetKey(KeyCode.UpArrow)    || Input.GetKey(KeyCode.W)) y += 1f;
        if (Input.GetKey(KeyCode.DownArrow)  || Input.GetKey(KeyCode.S)) y -= 1f;

        if (Application.isMobilePlatform)
        {
            x += Input.acceleration.x * 2f;
            y += (Input.acceleration.y + 0.5f) * 2f;
        }

        Vector3 move = transform.forward * forwardSpeed
                     + transform.right * x * moveSpeed
                     + Vector3.up * y * moveSpeed;

        Vector3 next = rb.position + move * Time.fixedDeltaTime;
        next.x = Mathf.Clamp(next.x, minX, maxX);
        next.y = Mathf.Clamp(next.y, minY, maxY);
        rb.MovePosition(next);

        CheckPass();
        CheckWin();
    }

    void CheckPass()
    {
        if (passZ == null || nextPass >= passZ.Length) return;

        float z = transform.position.z;
        bool passed = flyingTowardNegativeZ ? (z <= passZ[nextPass]) : (z >= passZ[nextPass]);

        if (passed)
        {
            if (passSound != null) passSound.Play();
            Debug.Log("通過第 " + (nextPass + 1) + " 座山,Z = " + z);
            nextPass++;
        }
    }

    void CheckWin()
{
    if (!alive) return;

    float z = transform.position.z;
    bool reached = flyingTowardNegativeZ ? (z <= winZ) : (z >= winZ);

    if (reached)
    {
        alive = false;
        Debug.Log("通關!Z = " + z);
        if (flySound != null) flySound.Stop();
        if (winSound != null) winSound.Play();
        else if (passSound != null) passSound.Play();
        if (winPanel != null) winPanel.SetActive(true);
        StartCoroutine(ShowButton());   // 改成跟失敗一樣,延遲後開按鈕
    }
}

    void OnCollisionEnter(Collision c) { HandleHit(c.gameObject); }
    void OnCollisionStay(Collision c)  { HandleHit(c.gameObject); }

    void HandleHit(GameObject other)
    {
        if (!alive || !other.CompareTag("Obstacle")) return;
        if (Time.time - lastHitTime < hitCooldown) return;

        lastHitTime = Time.time;
        lives--;

        if (lives >= 0 && lives < hearts.Length && hearts[lives] != null)
        {
            Image img = hearts[lives].GetComponent<Image>();
            if (img != null) img.enabled = false;
        }

        if (lives <= 0)
        {
            alive = false;
            if (flySound != null) flySound.Stop();
            if (finalHitSound != null) finalHitSound.Play();
            if (gameOverPanel != null) gameOverPanel.SetActive(true);
            if (restartButton != null) restartButton.SetActive(false);
            StartCoroutine(ShowButton());
        }
        else
        {
            if (hitSound != null) hitSound.Play();
            stunUntil = Time.time + stunTime;
        }
    }

    System.Collections.IEnumerator ShowButton()
    {
        yield return new WaitForSecondsRealtime(buttonDelay);
        if (restartButton != null) restartButton.SetActive(true);
        canRestart = true;
    }

    System.Collections.IEnumerator AllowRestart()
    {
        yield return new WaitForSecondsRealtime(buttonDelay);
        canRestart = true;
    }

    public void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}